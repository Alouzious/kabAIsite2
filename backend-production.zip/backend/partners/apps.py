from django.apps import AppConfig


class PartnersConfig(AppConfig):
    name = 'partners'
