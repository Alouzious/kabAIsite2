from django.apps import AppConfig


class IndabaxConfig(AppConfig):
    name = 'indabax'
